<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AuPropertyCertificate extends Model
{
    use HasFactory;
    protected $table = 'au_property_certificates';
    protected $guarded = [];
}
