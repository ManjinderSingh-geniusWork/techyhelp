<!DOCTYPE html>
 

<html>
    <head>
        <title>Techy Help - <?php echo $__env->yieldContent('title'); ?></title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/stargold.css']); ?>
    </head>
    <body>
        <?php $__env->startSection('sidebar'); ?>
            
        <?php echo $__env->yieldSection(); ?>
 
        <div class="container">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
        <div class ="fotter" style="position: fixed;right: 0;bottom: 0;">
            <span id="siteseal"><script async type="text/javascript" src="https://seal.godaddy.com/getSeal?sealID=4wlxWSyNRXGjBL5IfQ2W3dePmw3ZZSatVOUWsO9ntWE42qdpL65xJfGVqiN0"></script></span>
        </div>
    </body>
</html>
<?php /**PATH D:\wamp64\www\myproject\techyhelp\resources\views/layouts/stargold.blade.php ENDPATH**/ ?>